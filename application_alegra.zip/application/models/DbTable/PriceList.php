<?php

class Application_Model_DbTable_PriceList extends Zend_Db_Table_Abstract
{

    protected $_name = 'price_list';


}
